# ESCÁNER EMPRESA - GUÍA VISUAL STUDIO COMMUNITY Y DESPLIEGUE APK
Consulte la documentación completa para compilación en .NET 8.0 MAUI y despliegue en terminales Android.