using System;
using System.IO;

namespace EscanerEmpresa.Helpers
{
    public static class FileNameFormatter
    {
        public static string GenerateUniqueFileName(string rawBarcode, string targetDirectory, DateTime? timestamp = null)
        {
            if (string.IsNullOrWhiteSpace(rawBarcode))
                throw new ArgumentException("Código no válido.", nameof(rawBarcode));

            DateTime now = timestamp ?? DateTime.Now;
            string datePart = now.ToString("yyyyMMdd_HHmmss");
            string baseFileName = $"{rawBarcode}_{datePart}.txt";

            if (!Directory.Exists(targetDirectory)) return baseFileName;

            string fullPath = Path.Combine(targetDirectory, baseFileName);
            if (!File.Exists(fullPath)) return baseFileName;

            // Desambiguación si coinciden lecturas en el mismo segundo
            int counter = 1;
            while (true)
            {
                string candidate = $"{rawBarcode}_{datePart}_{counter:D2}.txt";
                if (!File.Exists(Path.Combine(targetDirectory, candidate)))
                    return candidate;
                counter++;
                if (counter > 999) return $"{rawBarcode}_{datePart}_{now:fffffff}.txt";
            }
        }
    }
}