using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;
using EscanerEmpresa.Models;

namespace EscanerEmpresa.Services
{
    public class ApiResponse
    {
        public bool IsSuccess { get; set; }
        public HttpStatusCode StatusCode { get; set; }
        public string Message { get; set; } = string.Empty;
        public string? ErrorDetails { get; set; }
    }

    public interface IApiService
    {
        string ApiUrl { get; set; }
        Task<ApiResponse> SendBarcodeFileAsync(PendingFile pendingFile, CancellationToken cancellationToken = default);
    }

    public class ApiService : IApiService
    {
        private readonly HttpClient _httpClient;
        private readonly INetworkService _networkService;
        public const string DefaultApiUrl = "https://API_EMPRESA/";
        public string ApiUrl { get; set; } = DefaultApiUrl;

        public ApiService(INetworkService networkService, HttpClient? httpClient = null)
        {
            _networkService = networkService ?? throw new ArgumentNullException(nameof(networkService));
            _httpClient = httpClient ?? new HttpClient { Timeout = TimeSpan.FromSeconds(15) };
        }

        public async Task<ApiResponse> SendBarcodeFileAsync(PendingFile pendingFile, CancellationToken cancellationToken = default)
        {
            if (pendingFile == null || !File.Exists(pendingFile.FilePath))
            {
                return new ApiResponse { IsSuccess = false, Message = "El archivo no existe." };
            }

            // Comprobar WiFi corporativa antes de enviar
            bool isCorporateOk = await _networkService.IsCorporateNetworkAvailableAsync(cancellationToken);
            if (!isCorporateOk)
            {
                return new ApiResponse
                {
                    IsSuccess = false,
                    Message = "Envío bloqueado: No hay conexión con la red corporativa."
                };
            }

            try
            {
                using var multipartContent = new MultipartFormDataContent();
                byte[] fileBytes = await File.ReadAllBytesAsync(pendingFile.FilePath, cancellationToken);
                var byteArrayContent = new ByteArrayContent(fileBytes);
                byteArrayContent.Headers.ContentType = new MediaTypeHeaderValue("text/plain");

                // Campo "file" obligatorio y nombre original preservado
                multipartContent.Add(byteArrayContent, "file", pendingFile.FileName);

                using var response = await _httpClient.PostAsync(ApiUrl, multipartContent, cancellationToken);
                int statusCode = (int)response.StatusCode;

                // Códigos válidos: 200, 201, 204
                if (statusCode == 200 || statusCode == 201 || statusCode == 204)
                {
                    return new ApiResponse
                    {
                        IsSuccess = true,
                        StatusCode = response.StatusCode,
                        Message = $"Archivo enviado correctamente (HTTP {statusCode})."
                    };
                }
                else
                {
                    string details = await response.Content.ReadAsStringAsync(cancellationToken);
                    return new ApiResponse
                    {
                        IsSuccess = false,
                        StatusCode = response.StatusCode,
                        Message = $"Error de la API: HTTP {statusCode}",
                        ErrorDetails = details
                    };
                }
            }
            catch (Exception ex)
            {
                return new ApiResponse
                {
                    IsSuccess = false,
                    Message = $"Error durante el envío: {ex.Message}",
                    ErrorDetails = ex.ToString()
                };
            }
        }
    }
}