using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Input;
using EscanerEmpresa.Models;
using EscanerEmpresa.Services;
using Microsoft.Maui.ApplicationModel;
using Microsoft.Maui.Controls;
using ZXing.Net.Maui;

namespace EscanerEmpresa.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        private readonly INetworkService _networkService;
        private readonly IFileService _fileService;
        private readonly IApiService _apiService;
        private readonly IScannerService _scannerService;

        private int _isProcessingScanLock = 0;

        private ConnectionState _connectionStatus = ConnectionState.ComprobandoConexion;
        private ScannerState _scannerStatus = ScannerState.Preparado;
        private FileState _fileStatus = FileState.Inactivo;
        private SendState _sendStatus = SendState.Inactivo;

        private string _lastScannedCode = "Ninguno";
        private string _lastGeneratedFileName = "-";
        private string _statusMessage = "Listo para escanear.";
        private bool _isBusy = false;
        private bool _isCameraActive = false;
        private bool _torchEnabled = false;
        private int _pendingFilesCount = 0;

        public event PropertyChangedEventHandler? PropertyChanged;

        public ConnectionState ConnectionStatus
        {
            get => _connectionStatus;
            set { if (_connectionStatus != value) { _connectionStatus = value; OnPropertyChanged(); OnPropertyChanged(nameof(ConnectionStatusText)); } }
        }
        public string ConnectionStatusText => _connectionStatus.ToDisplayText();

        public ScannerState ScannerStatus
        {
            get => _scannerStatus;
            set { if (_scannerStatus != value) { _scannerStatus = value; OnPropertyChanged(); OnPropertyChanged(nameof(ScannerStatusText)); } }
        }
        public string ScannerStatusText => _scannerStatus.ToDisplayText();

        public FileState FileStatus
        {
            get => _fileStatus;
            set { if (_fileStatus != value) { _fileStatus = value; OnPropertyChanged(); OnPropertyChanged(nameof(FileStatusText)); } }
        }
        public string FileStatusText => _fileStatus.ToDisplayText();

        public SendState SendStatus
        {
            get => _sendStatus;
            set { if (_sendStatus != value) { _sendStatus = value; OnPropertyChanged(); OnPropertyChanged(nameof(SendStatusText)); } }
        }
        public string SendStatusText => _sendStatus.ToDisplayText();

        public string LastScannedCode
        {
            get => _lastScannedCode;
            set { if (_lastScannedCode != value) { _lastScannedCode = value; OnPropertyChanged(); } }
        }

        public string LastGeneratedFileName
        {
            get => _lastGeneratedFileName;
            set { if (_lastGeneratedFileName != value) { _lastGeneratedFileName = value; OnPropertyChanged(); } }
        }

        public string StatusMessage
        {
            get => _statusMessage;
            set { if (_statusMessage != value) { _statusMessage = value; OnPropertyChanged(); } }
        }

        public bool IsBusy
        {
            get => _isBusy;
            set { if (_isBusy != value) { _isBusy = value; OnPropertyChanged(); OnPropertyChanged(nameof(CanOpenScan)); } }
        }

        public bool IsCameraActive
        {
            get => _isCameraActive;
            set { if (_isCameraActive != value) { _isCameraActive = value; OnPropertyChanged(); } }
        }

        public bool TorchEnabled
        {
            get => _torchEnabled;
            set { if (_torchEnabled != value) { _torchEnabled = value; OnPropertyChanged(); } }
        }

        public int PendingFilesCount
        {
            get => _pendingFilesCount;
            set { if (_pendingFilesCount != value) { _pendingFilesCount = value; OnPropertyChanged(); OnPropertyChanged(nameof(HasPendingFiles)); } }
        }
        public bool HasPendingFiles => _pendingFilesCount > 0;
        public bool CanOpenScan => !IsBusy && !IsCameraActive;
        public BarcodeReaderOptions BarcodeReaderOptions => _scannerService.BarcodeReaderOptions;

        public ICommand AbrirCamaraCommand { get; }
        public ICommand CerrarCamaraCommand { get; }
        public ICommand ReintentarEnviosCommand { get; }
        public ICommand VerificarConexionCommand { get; }
        public ICommand ToggleTorchCommand { get; }

        public MainViewModel(
            INetworkService networkService,
            IFileService fileService,
            IApiService apiService,
            IScannerService scannerService)
        {
            _networkService = networkService;
            _fileService = fileService;
            _apiService = apiService;
            _scannerService = scannerService;

            AbrirCamaraCommand = new Command(async () => await OnAbrirCamaraAsync(), () => CanOpenScan);
            CerrarCamaraCommand = new Command(() => { IsCameraActive = false; ScannerStatus = ScannerState.Preparado; });
            ReintentarEnviosCommand = new Command(async () => await OnReintentarEnviosAsync(), () => !IsBusy);
            VerificarConexionCommand = new Command(async () => await CheckCorporateConnectionAsync(), () => !IsBusy);
            ToggleTorchCommand = new Command(() => TorchEnabled = !TorchEnabled);

            _ = InitializeAppAsync();
        }

        private async Task InitializeAppAsync()
        {
            await RefreshPendingFilesCountAsync();
            await CheckCorporateConnectionAsync();
        }

        public async Task CheckCorporateConnectionAsync()
        {
            ConnectionStatus = ConnectionState.ComprobandoConexion;
            StatusMessage = "Comprobando conexión con red WiFi corporativa...";
            bool isConnected = await _networkService.IsCorporateNetworkAvailableAsync();

            if (isConnected)
            {
                ConnectionStatus = ConnectionState.ConectadoRedCorporativa;
                StatusMessage = "Conectado a la red corporativa. Listo para escanear.";
            }
            else
            {
                ConnectionStatus = ConnectionState.SinConexionCorporativa;
                StatusMessage = "Sin conexión corporativa. Conecte el dispositivo a la red WiFi autorizada.";
            }
        }

        private async Task OnAbrirCamaraAsync()
        {
            if (IsBusy) return;

            // 1. Comprobar red corporativa antes de abrir cámara
            bool isNetworkOk = await _networkService.IsCorporateNetworkAvailableAsync();
            if (!isNetworkOk)
            {
                ConnectionStatus = ConnectionState.SinConexionCorporativa;
                StatusMessage = "Acceso bloqueado: Debe estar conectado a la red WiFi corporativa para abrir el escáner.";
                return;
            }
            ConnectionStatus = ConnectionState.ConectadoRedCorporativa;

            // 2. Comprobar permiso de cámara
            var perm = await _scannerService.CheckAndRequestCameraPermissionAsync();
            if (perm != PermissionStatus.Granted)
            {
                StatusMessage = "Permiso de cámara denegado.";
                return;
            }

            Interlocked.Exchange(ref _isProcessingScanLock, 0);
            IsCameraActive = true;
            ScannerStatus = ScannerState.LeyendoCodigo;
            StatusMessage = "Cámara abierta. Apunte al código de barras.";
        }

        public async Task HandleBarcodeDetectedAsync(BarcodeResult[] results)
        {
            if (results == null || results.Length == 0) return;

            // Concurrency lock: solo una lectura procesada por escaneo
            if (Interlocked.CompareExchange(ref _isProcessingScanLock, 1, 0) != 0) return;

            var result = results[0];
            if (!_scannerService.ValidateBarcodeFormat(result))
            {
                Interlocked.Exchange(ref _isProcessingScanLock, 0);
                return;
            }

            // Detener cámara inmediatamente
            IsCameraActive = false;
            ScannerStatus = ScannerState.CodigoLeido;
            IsBusy = true;

            // Preservar ceros iniciales como string
            string rawBarcode = result.Value;
            LastScannedCode = rawBarcode;
            StatusMessage = $"Código leído: {rawBarcode}. Procesando archivo...";

            try
            {
                FileStatus = FileState.GenerandoArchivo;
                var pendingFile = await _fileService.CreateBarcodeFileAsync(rawBarcode);
                FileStatus = FileState.ArchivoGenerado;
                LastGeneratedFileName = pendingFile.FileName;

                SendStatus = SendState.EnviandoArchivo;
                var apiResponse = await _apiService.SendBarcodeFileAsync(pendingFile);

                if (apiResponse.IsSuccess)
                {
                    await _fileService.MarkFileAsSentAsync(pendingFile.FileName);
                    SendStatus = SendState.EnviadoCorrectamente;
                    StatusMessage = $"Archivo enviado con éxito a la API. Código: {rawBarcode}";
                }
                else
                {
                    SendStatus = SendState.ErrorEnvio;
                    StatusMessage = $"Error de envío: {apiResponse.Message}. Archivo guardado para reintento.";
                }
            }
            catch (Exception ex)
            {
                FileStatus = FileState.ErrorGenerarArchivo;
                SendStatus = SendState.ErrorEnvio;
                StatusMessage = $"Error: {ex.Message}";
            }
            finally
            {
                await RefreshPendingFilesCountAsync();
                IsBusy = false;
                ScannerStatus = ScannerState.Preparado;
            }
        }

        private async Task OnReintentarEnviosAsync()
        {
            if (IsBusy) return;
            IsBusy = true;

            try
            {
                bool isNetworkOk = await _networkService.IsCorporateNetworkAvailableAsync();
                if (!isNetworkOk)
                {
                    ConnectionStatus = ConnectionState.SinConexionCorporativa;
                    StatusMessage = "No se pueden reintentar envíos: Sin conexión con la red corporativa.";
                    return;
                }

                var pending = await _fileService.GetPendingFilesAsync();
                if (pending.Count == 0) return;

                int sentCount = 0;
                foreach (var file in pending)
                {
                    SendStatus = SendState.EnviandoArchivo;
                    var res = await _apiService.SendBarcodeFileAsync(file);
                    if (res.IsSuccess)
                    {
                        await _fileService.MarkFileAsSentAsync(file.FileName);
                        sentCount++;
                    }
                }

                await RefreshPendingFilesCountAsync();
                SendStatus = SendState.EnviadoCorrectamente;
                StatusMessage = $"{sentCount} archivos enviados con éxito.";
            }
            finally
            {
                IsBusy = false;
            }
        }

        public async Task RefreshPendingFilesCountAsync()
        {
            try
            {
                var list = await _fileService.GetPendingFilesAsync();
                PendingFilesCount = list.Count;
            }
            catch { PendingFilesCount = 0; }
        }

        protected void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}