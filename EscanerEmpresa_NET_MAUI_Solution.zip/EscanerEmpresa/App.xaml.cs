using Microsoft.Maui.Controls;
namespace EscanerEmpresa
{
    public partial class App : Application
    {
        public App(AppShell appShell)
        {
            InitializeComponent();
            MainPage = appShell;
        }
    }
}