namespace EscanerEmpresa.Models
{
    public enum ConnectionState
    {
        ComprobandoConexion,
        ConectadoRedCorporativa,
        SinConexionCorporativa
    }

    public enum ScannerState
    {
        Preparado,
        AbriendoCamara,
        LeyendoCodigo,
        CodigoLeido
    }

    public enum FileState
    {
        Inactivo,
        GenerandoArchivo,
        ArchivoGenerado,
        ErrorGenerarArchivo
    }

    public enum SendState
    {
        Inactivo,
        PendienteEnvio,
        EnviandoArchivo,
        EnviadoCorrectamente,
        ErrorEnvio
    }

    public static class AppStatusExtensions
    {
        public static string ToDisplayText(this ConnectionState state) => state switch
        {
            ConnectionState.ComprobandoConexion => "Comprobando conexión...",
            ConnectionState.ConectadoRedCorporativa => "Conectado a red corporativa",
            ConnectionState.SinConexionCorporativa => "Sin conexión corporativa",
            _ => "Desconocido"
        };

        public static string ToDisplayText(this ScannerState state) => state switch
        {
            ScannerState.Preparado => "Preparado",
            ScannerState.AbriendoCamara => "Abriendo cámara...",
            ScannerState.LeyendoCodigo => "Leyendo código...",
            ScannerState.CodigoLeido => "Código leído",
            _ => "Inactivo"
        };

        public static string ToDisplayText(this FileState state) => state switch
        {
            FileState.Inactivo => "-",
            FileState.GenerandoArchivo => "Generando archivo...",
            FileState.ArchivoGenerado => "Archivo generado",
            FileState.ErrorGenerarArchivo => "Error al generar archivo",
            _ => "-"
        };

        public static string ToDisplayText(this SendState state) => state switch
        {
            SendState.Inactivo => "-",
            SendState.PendienteEnvio => "Pendiente de envío",
            SendState.EnviandoArchivo => "Enviando archivo...",
            SendState.EnviadoCorrectamente => "Enviado correctamente (OK)",
            SendState.ErrorEnvio => "Error de envío",
            _ => "-"
        };
    }
}